import React from 'react'

export const AddStudentController = () => {
  return (
    <div>AddStudentController</div>
  )
}
