import React from 'react'

export const AcademicInformationController = () => {
  return (
    <div>AcademicInformationController</div>
  )
}
