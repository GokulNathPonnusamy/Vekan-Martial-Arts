import { SideBar } from './SideBar/SideBar';

export const Admin = () => {
  return (
    <>
    <SideBar />
    </>
  )
}
