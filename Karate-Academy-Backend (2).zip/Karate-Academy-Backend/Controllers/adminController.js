const bcrypt = require("bcrypt");
const connection = require("../db/index.js");
const jwt = require("jsonwebtoken");
const { SECRET } = require("../middleware/auth.js");


const adminRegister = async (req, res) => {
    try {
        let {name, email, username, password} = req.body;

        if (!name || !email || !username || !password) {
            return res.status(400).json({message: "All fields are required"});
        }

        username = username.toLowerCase();
        password = password.toLowerCase();

        if (password.length < 8) {
            return res.status(400).json({message: "Your password must be at least 8 characters"});
        }

        const getAdminQuery = `SELECT * FROM admin WHERE username=?`;
        
        connection.query(getAdminQuery, [username], async (error, results) => {
            if (error) {
                console.log("Error retrieving admin: ", error);
                return res.status(500).json({message: "Internal Server Error"});
            }
            
            if (results.length !== 0) {
                return res.status(400).json({message: "Admin already exists"});
            } else {
                const hashedPassword = await bcrypt.hash(password, 10);

                const createNewAdminQuery = `INSERT INTO admin(name, email, username, password) VALUES(?, ?, ?, ?)`;

                connection.query(createNewAdminQuery, [name, email, username, password], (error, results) => {
                    if (error) {
                        console.log("Error creating new admin: ", error);
                        return res.status(500).json({message: "Internal Server Error"});
                    }
                    
                    return res.status(201).json({message: "Admin registered successfully"})
                })
            }
        })
    } catch(error) {
        return res.status(500).json({message: "Internal Server Error"});
    }
}

const adminLogin = async (req, res) => {
    try{
        let {username, password} = req.body;

        console.log("🔹 Received admin Login Request");
        console.log("🔹 Request Body:", req.body);

        console.log(username);
        console.log(password);
        
        if (!username || !password) {
            console.error("Missing Fields in Request Body:", req.body);
            return res.status(400).json({message: "All fields are required"});
        }

        username = username.toLowerCase();
        password = password.toLowerCase();

        const getAdminQuery = `SELECT * FROM admin WHERE username=?`;

        connection.query(getAdminQuery, [username], async (error, results) => {
            if (error) {
                console.log("Error in admin login api: ", error);
                return res.status(500).json({message: "Internal Server Error"});
            }

            if (results.length === 0) {
                // console.log("fine");
                return res.status(400).json({message: "Invalid Username"});
            } else {
                // const storedUsername = results[0].username;
                const storedPassword = results[0].password;

                // // Debugging: Compare hashed passwords
                console.log("Stored Password: ", storedPassword);
                console.log("Entered Password: ", password);

                // const isPasswordMatched = await bcrypt.compare(password, storedPassword);
                // const isPasswordMatched = await bcrypt.compare(password, results[0].password);

                // console.log(isPasswordMatched);
                if (storedPassword === password) {
                    const payload = {
                        user_id: results[0].admin_id,
                        role: 'admin'
                    }

                    const jwtToken = jwt.sign(payload, SECRET, {expiresIn: '30d'});
                    
                    return res.status(201).json({jwtToken: jwtToken});

                } else {
                    return res.status(400).json({message: "Invalid Password"});
                }
            }
        })


    } catch (error) {
        return res.status(500).json({message: "Internal Server Error"});
    }
}


module.exports = {adminLogin, adminRegister}