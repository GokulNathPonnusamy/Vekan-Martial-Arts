const connection = require("../db/index.js");
const fs = require("fs").promises;

const uploadCertificate = async (req, res) => {
    try {
        const {student_id, course_id, issue_date, certificate_name} = req.body;

        if (!student_id || !course_id || !issue_date || !certificate_name) {
            return res.status(400).json({message: "All fields are required"});
        }

        const file = req.file;

        if (!file) {
            return res.status(400).json({message: "No file uploaded"});
        }

        const imageBuffer = await fs.readFile(file.path);

        const insertCertificateQuery = `INSERT INTO certificate (student_id, course_id, issue_date, certificate_name, certificate_file)
                                        VALUES (?, ?, ?, ?, ?)`;

        connection.query(insertCertificateQuery, [student_id, course_id, issue_date, certificate_name, imageBuffer], async (error, results) => {
            if (error) {
                console.log("Error uploading certificate: ", error);
                return res.status(500).json({message: "Internal Server Error"});
            }

            await fs.unlink(file.path);
            if (results.affectedRows === 1) {
                return res.status(200).json({message: "Certificate uploaded to database", certificate_id: results.insertId});
            }
        });
    
    } catch(error) {
        return res.status(500).json({message: "Internal Server Error"});
    }
};

const updateCertificate = async (req, res) => {
    try {
        const {certificateId} = req.params;
        const {student_id, course_id, issue_date, certificate_name} = req.body;

        if (!student_id || !course_id || !issue_date || !certificate_name) {
            return res.status(400).json({message: "All fields are required"});
        }

        const file = req.file;
        const imageBuffer = file ? await fs.readFile(file.path) : null;

        const certificateIdQuery = `SELECT * FROM certificate WHERE certificate_id = ?`;

        connection.query(certificateIdQuery, [certificateId], (error, results) => {
            if (error) {
                console.log("Error validating certificate ID: ", error);
                return res.status(500).json({message: "Internal Server Error"});
            }

            if (results.length === 0) {
                return res.status(400).json({message: "Invalid certificate ID"});
            } else {
                const updateCertificateQuery = `UPDATE certificate 
                                                SET student_id = ?, course_id = ?, issue_date = ?, certificate_name = ?, 
                                                    certificate_file = COALESCE(?, certificate_file) 
                                                WHERE certificate_id = ?`;

                connection.query(updateCertificateQuery, [student_id, course_id, issue_date, certificate_name, imageBuffer, certificateId], async (error, results) => {
                    if (error) {
                        console.log("Error updating certificate: ", error);
                        return res.status(500).json({message: "Internal Server Error"});
                    }
                    
                    if (file) await fs.unlink(file.path);
                    if (results.affectedRows === 1) {
                        return res.status(201).json({message: 'Certificate updated successfully'});
                    }
                });
            }
        });

    } catch(error) {
        return res.status(500).json({message: "Internal Server Error"});
    }
};

const deleteCertificate = (req, res) => {
    try {
        let id = req.body.certificate_id || req.body.student_id;

        const checkCertificateIdQuery = `SELECT * FROM certificate WHERE ${req.opt}_id = ?`;

        connection.query(checkCertificateIdQuery, [id], (error, results) => {
            if (error) {
                console.log(`Error validating ${req.opt} ID: `, error);
                return res.status(500).json({message: "Internal Server Error"});
            }

            if (results.length === 0) {
                return res.status(400).json({message: `Invalid ${req.opt}`}); 
            } else {
                const deleteCertificateQuery =  `DELETE FROM certificate WHERE ${req.opt}_id = ?`;

                connection.query(deleteCertificateQuery, [id], (error, results) => {
                    if (error) {
                        console.log("Error deleting certificate: ", error);
                        return res.status(500).json({message: "Internal Server Error"});
                    }

                    return res.status(200).json({message: "Certificate deleted successfully"});
                });
            }
        });

    } catch(error) {
        return res.status(500).json({message: "Internal Server Error"});
    }
};

const getAllCertificates = (req, res) => {
    try {
        let {certificate_id, student_id, course_id} = req.query;
        let params = [];
        let getCertificatesQuery = `SELECT certificate_id, certificate_name, student.name AS student_name, course_name, issue_date 
                                    FROM certificate 
                                    INNER JOIN student ON certificate.student_id = student.student_id
                                    INNER JOIN course ON certificate.course_id = course.course_id`;

        if (certificate_id) {
            params.push(certificate_id);
            getCertificatesQuery += ` WHERE certificate.certificate_id = ?`;
        }

        if (student_id) {
            getCertificatesQuery += params.length > 0 ? ' AND' : ' WHERE';
            getCertificatesQuery += ` certificate.student_id = ?`;
            params.push(student_id);
        }

        if (course_id) {
            getCertificatesQuery += params.length > 0 ? ' AND' : ' WHERE';
            getCertificatesQuery += ` certificate.course_id = ?`;
            params.push(course_id);
        }

        connection.query(getCertificatesQuery, params, (error, results) => {
            if (error) {
                console.log("Error getting certificates: ", error);
                return res.status(500).json({message: 'Internal Server Error'});
            }

            return res.status(200).json({certificates: results});
        });

    } catch(error) {
        console.log(error);
        return res.status(500).json({message: "Internal Server Error"});
    }
};

const getCertificate = (req, res) => {
    try {
        const {certificateId} = req.params;

        const checkCertificateIdQuery = `SELECT certificate_name, certificate_file FROM certificate WHERE certificate_id = ?`;

        connection.query(checkCertificateIdQuery, [certificateId], (error, results) => {
            if (error) {
                console.log("Error validating certificate ID: ", error);
                return res.status(500).json({message: 'Internal Server Error'});
            }

            if (results.length === 0) {
                return res.status(400).json({message: 'Certificate not found'});
            } else {
                const {certificate_name, certificate_file} = results[0];

                res.setHeader('Content-Disposition', `attachment; filename="${certificate_name}.jpg"`);
                res.setHeader('Content-Type', 'image/jpeg');

                return res.status(200).send(certificate_file);
            }
        });

    } catch(error) {
        console.log(error);
        return res.status(500).json({message: "Internal Server Error"});
    }
};

const getStudentCertificates = (req, res) => {
    try {
        const { student_id } = req.params;
        const getCertificatesQuery = `SELECT certificate_id, certificate_name, certificate_file FROM certificate WHERE student_id = ?`;

        connection.query(getCertificatesQuery, [student_id], (error, results) => {
            if (error) {
                console.log("Error fetching certificates: ", error);
                return res.status(500).json({ message: 'Internal Server Error' });
            }
        
            if (results.length === 0) {
                return res.status(404).json({ message: 'No certificates found for this student.' });
            }
        
            const certificates = results.map(cert => ({
                certificateId: cert.certificate_id,
                certificateName: cert.certificate_name,
                image: cert.certificate_file
                    ? `data:image/jpeg;base64,${Buffer.from(cert.certificate_file).toString('base64')}`
                    : null
            }));

            res.status(200).json({ student_id, certificates });
        });

    } catch (error) {
        console.log("Error: ", error);
        return res.status(500).json({ message: "Internal Server Error" });
    }
};

module.exports = {uploadCertificate, updateCertificate, deleteCertificate, getAllCertificates, getCertificate, getStudentCertificates};